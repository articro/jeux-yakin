PSX People Free
===============

An office worker and a survivor woman with 10 animations each, taken from PSX People (24 people,
240 animations): https://heyheythere.itch.io/psx-people
Low-poly, one 1024x1024 point-filtered texture atlas, the shading baked into vertex colours,
real-world scale (1 unit = 1 metre).

What's in the zip
-----------------
glb/        one file per person, with its animations (the best format for Godot, Blender, three.js)
fbx/        one file per person, with its animations as takes (Unreal, Unity, most 3D apps)
obj/        one file per person, in its bind pose (any 3D app)
textures/   atlas.png, the one texture every person uses
icons/      an icon per person, 256x256 PNG with transparency
props.json  every person: title, group, size, triangles, parts and animations
blender/    both people in one .blend, the atlas packed in
addons/     the Godot addon, psx_people/: this folder is a Godot 4.3+ project that opens on
            its gallery (.gdignore keeps Godot out of the other folders)

The people
----------
Each is rigid parts that turn at their joints, the way PS1 characters were made, rigged: one mesh
on an armature, each part weighted whole to its bone (a forearm's bone under its upper arm's, under
the spine's, under the hips'), so turning one carries the ones below it. Each is bound in a T-pose
with its bones named as Mixamo names them (Hips, Spine, Head, LeftArm, LeftForeArm, LeftHand,
LeftUpLeg, LeftLeg, LeftFoot and the Right ones); a hat or a backpack is part of the head or the
spine. Its origin is on the ground under it, and it faces Blender's -Y (+Z in Godot and Unity).
Every person has the same ten animations:
  idle            a loop: standing at ease, looking about
  walk, run       loops; they play in place, for your code to move the person
  talk            a loop: talking with the hands, nodding
  wave            a loop: waving over the head
  sit             a loop: sitting where it stands, on a seat about 0.4 m high
  cower           a loop: crouched, arms over the head, trembling
  attack          a punch, once
  hit             a flinch, once, back to where it started
  death           a fall, once, ending on the ground
Their lengths are in props.json.

Godot 4.3 and later
-------------------
Copy addons/psx_people/ into your project's addons/ folder. Each person is a scene in props/:
drag it into your level. It has its mesh on a Skeleton3D, a box collider (StaticBody3D) on each
bone that moves with it, and an AnimationPlayer:

    office_worker.get_node("AnimationPlayer").play("talk")   # an instance of props/office_worker.tscn

icons/ has the icons. demo/gallery.tscn shows every person: drag to turn, arrows to browse, its
buttons to play its animations, A for all of them at once.
The people use one material, props.tres: the atlas times the vertex colours, lit, so your lights
fall on them. For the full PS1 look (vertex snap, affine textures, 240p, dither), our PSX Look
shaders turn them over in one line: https://heyheythere.itch.io/psx-look
With PSX Look in res://addons/psx_look/, the gallery shows the people through it (P toggles it).

Other engines and apps
----------------------
Use fbx/, glb/ or obj/ with textures/atlas.png. Set the texture's filtering to nearest/point and
turn off mipmaps for the crisp PS1 texels, and multiply it by the vertex colours (the baked
shading) in your material.

License: see LICENSE.txt. Made by heyheythere: https://heyheythere.itch.io
